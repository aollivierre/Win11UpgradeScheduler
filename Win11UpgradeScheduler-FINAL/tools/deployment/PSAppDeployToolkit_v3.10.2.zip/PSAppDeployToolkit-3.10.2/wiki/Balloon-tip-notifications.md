Balloon tip notifications are displayed in the system tray automatically at the beginning and end of the installation. These can be turned off in the XML configuration.

![](images/image15.png)

![](images/image16.png)

![](images/image17.png)
