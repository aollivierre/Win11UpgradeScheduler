# About Us

The PowerShell App Deployment Toolkit was launched in August 2013 and is a joint collaboration between Seán Lillis and Dan Cunningham. A number of developers have since joined the project team:

- Muhammad Mashwani - October 2014

- Aman Motazedian - August 2015

- Dennis Van Hoylandt - January 2018

- Lukáš Čeremeta - September 2019

The founders' personal websites are listed below, where you can learn more about them or get in contact with them.

## Seán Lillis

[Website](http://powersheller.wordpress.com)

[Twitter](https://twitter.com/seanels)

## Dan Cunningham

[LinkedIn](https://www.linkedin.com/in/sintaxasn)

[Twitter](https://twitter.com/sintaxasn)
