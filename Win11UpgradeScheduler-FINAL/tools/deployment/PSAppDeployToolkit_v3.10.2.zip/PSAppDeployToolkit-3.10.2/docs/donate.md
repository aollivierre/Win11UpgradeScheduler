# Donate

The PowerShell App Deployment Toolkit has been built over many years in the spare time of the developers and continues to be supported as such.

It has become a widely used framework and is used in many top 500 Fortune organisations globally.

If you would like to make a contribution to support the continued development of the toolkit, please get in contact with us via **psappdeploytoolkit at gmail dot com**
