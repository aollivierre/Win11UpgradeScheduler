# PSAppDeployToolkit Support

If you have any problems, please consult the [PSAppDeployToolkit GitHub Issues](https://github.com/psappdeploytoolkit/psappdeploytoolkit/issues) page.

If you do not see your problem captured, please file a [new issue](https://github.com/psappdeploytoolkit/psappdeploytoolkit/issues/new/choose) and follow the provided template.

If you know how to fix the issue, feel free to send a pull request our way. (The [Contribution Guide](https://github.com/psappdeploytoolkit/psappdeploytoolkit/tree/main/.github/CONTRIBUTING.md) apply to that pull request, you may want to give it a read!)
